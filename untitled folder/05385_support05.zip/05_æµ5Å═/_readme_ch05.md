# 第5章_提供データ
 - 実証例などで使用する要藤（2005）データ：youdou.dta，youdou.csv
 - 実証例などの分析コード：chap5_main.do
 - 練習問題5-15で使用するTIMSSデータ：timss.dta
 - TIMSSデータの変数名定義ファイル：timss_variable_definition.txt
 - 練習問題5-15の分析コード：chap5_exercise15.do

