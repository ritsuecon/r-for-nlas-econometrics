# 第8章_提供データ
 - 実証例などで使用するPIAACデータ：piaac.dta, piaac.csv
 - piaac.dtaの整形前元データ：piaac_jpn.dta, piaac_jpn.csv
 - piaac_jpn.dtaデータの変数名定義ファイル：International Codebook_PIAAC Public-use File (PUF) Variables and Values.xlsx
 - 実証例などの分析コード：chap8_main.do
 - piaac_jpn.dtaからpiaac.dtaへの整形スクリプト：crpiaac.do

