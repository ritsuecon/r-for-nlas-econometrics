# 第7章_提供データ
 - 実証例などで使用するBecker and Woessmann（2009）データ：ipehd_qje2009_master.dta，ipehd_qje2009_master.csv
 - Becker and Woessmann（2009）データの変数名定義ファイル：ipehd_qje2009_master_variable_definition.txt
 - 実証例などの分析コード：chap7_main.do
