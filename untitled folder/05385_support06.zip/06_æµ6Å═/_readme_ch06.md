# 第6章_提供データ
 - 実証例などで使用するAsai, Kambayashi, Yamaguchi（2015）データ：yamaguchi.dta，yamaguchi.csv
 - Asai, Kambayashi, Yamaguchi（2015）データの変数名定義ファイル：yamaguchi_variable_definition.txt
 - 実証例などの分析コード：chap6_main.do
 - 練習問題6-11で使用するTIMSSデータ：timss.dta
 - TIMSSデータの変数名定義ファイル：timss_variable_definition.txt
 - 練習問題6-11の分析コード：chap6_exercise11.do

