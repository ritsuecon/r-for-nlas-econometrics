# 第4章_提供ファイル
 - 実証例で使用する実質賃金と労働生産性のデータ：ch04_wage.csv
 - 実証例の再現コード（Stata）：ch04_main.do
 - 練習問題4-2で使用するデータ：data for chap 4 exercise 2.xlsx
 - 練習問題4-10で使用するデータ：data for chap 4 exercise 10.xlsx

